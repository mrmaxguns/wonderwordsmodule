a = True
b = False
c = True

if b:
    print('a')
if b:
    print('b')
if b:
    print('c')
else:
    print('bob')